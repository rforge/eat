####################################################################################################################
#
# function:
# removeNAcols ( data , rows = NULL , tolerance = 0 , cumulate = TRUE , method = c("remove", "identify") , warn = FALSE )
#
# description:
# removes or identifies columns with NA
#
# arguments:
# data: matrix or dataframe
# rows: rows (numeric vector or row names) or list of row subsets that are tested for NA, default: all rows
# tolerance: number or list of numbers (corresponding to row subsets) of allowed non-NA 
# cumulate: if TRUE columns that match tolerance criterion are cumulated, if FALSE columns that match NA pattern exactly are removed or identified
# method: "remove" removes cols from data , "identify" identifies cols to be removed
# warn: if TRUE a warning is issued when cols are removed (method="remove" only)
#
# value:
# method="remove" returns matrix or dataframe with cols removed
# method="identify" returns list of cols that were identified to be removed
#
# Version: 	0.1.0
# Depends: 	codeKlandestin
# Imports: 	codeKlandestin
# Published: 	2011-08-08
# Author: 	Martin Hecht
# Maintainer: 	Martin Hecht
#
# Change-Log
# 08.08.2011 MH: auf stable gesetzt wegen besserer sourcebarkeit
#				 Dependencies rausgenommen, muss jetzt �ber source.it.all gesourct werden
# 24.01.2011 MH		bugfix: data.frame column classes preserved
#					option "cumulate" added
# 21.01.2011 MH
# 15.01.2011 MH
#
####################################################################################################################

removeNAcols <- function( data , rows = NULL , tolerance = 0 , cumulate = TRUE , method = c("remove", "identify") , warn = FALSE ) {

		# Dependencies
		#source("c:/R/codeKlandestin_0.0.1.R")
		#source("p:/ZKD/stable/codeKlandestin.R")
		#source("p:/ZKD/development/codeKlandestin_0.0.2.R")
		
		# data transponieren um removeNA mit mode="cols" zu benutzen
		data.t <- t(data)

		# wieder zum Dataframe machen, da t() nur Matrix zur�ckgibt
		# colnames setzen
		if ( class(data)=="data.frame" ) {
				data.t <- as.data.frame(data.t)
				colnames(data.t) <- rownames(data)
		}
		
		# removeNA mit transponierten Datensatz und mode="cols" aufrufen
		# Hinweis: removeNA ist standardm��ig auf rows l�schen programmiert,
		# deshalb der ganze Spa� mit dem transponieren
		data.return <- removeNA ( data.t , rows , tolerance , cumulate , method , warn , mode="cols")

		# nur bei method="remove" r�cktransponieren, da method="identify" ne Liste liefert,
		# die nicht transponiert werden darf
		if (method[1]=="remove") { 
				data.return <- t( data.return )
		
				### wenn Input Dataframe dann
				# Output nach Dataframe wandeln
				# urspr�ngliche rownames wieder herstellen
				# Spalten-Klassen setzen
				if ( class(data)=="data.frame" ) { 
						data.return <- data.frame(data.return)
						rownames(data.return) <- rownames(data)
						for (colnum in seq(along=data.return))  data.return[,colnum] <- as ( data.return[,colnum] , class(data[, colnames(data.return)[colnum] ]) )
				}	
		}

		return ( data.return )
}


####################################################################################################################
# E x a m p l e s
####################################################################################################################

### example matrix
#( mat <- matrix( c( 1,1,1,1,1,1, 1,1,1,1,1,NA, 1,1,1,1,NA,NA, 1,1,1,NA,NA,NA, 1,1,NA,NA,NA,NA, 1,NA,NA,NA,NA,NA, NA,NA,NA,NA,NA,NA) , ncol=7 ) )

### remove column with entirely NA (column 7)
#removeNAcols( mat )

### warning message if cols are removed
#removeNAcols( mat , warn = TRUE )

### remove column with NA on rows 3, 4, 5 (columns 5, 6, 7)
#removeNAcols( mat , c(3,4,5) ) 
#removeNAcols( mat , c(-1,-2,-6) ) 

### tolerance=1 , 1 non-NA is permitted (columns 6 and 7)
#removeNAcols( mat , tolerance=1 ) 

### tolerance=6 , 6 non-NA are permitted (all columns are removed)
#removeNAcols( mat , tolerance=6 ) 

### do not cumulate / exact tolerance (column 1)
#removeNAcols( mat , tolerance=6 , cumulate=FALSE ) 

### two subsets of rows
#removeNAcols( mat , rows = list( c(1, 2), c(4, 5) ) )

### two subsets of rows with different tolerance
#removeNAcols( mat , rows = list( c(1), c(2, 3, 4, 5) ) , tolerance = list( 0 , 1 ) )

### identify cols, no deletion
#removeNAcols( mat , rows = list( c(1, 2), c(3, 4, 5) ) , tolerance = list( 0 , 1 ) , method = "identify" )



####################################################################################################################
# T e s t s
####################################################################################################################

### test matrix
#( mat <- matrix( c( 1,1,1,1,1,1, 1,1,1,1,1,NA, 1,1,1,1,NA,NA, 1,1,1,NA,NA,NA, 1,1,NA,NA,NA,NA, 1,NA,NA,NA,NA,NA, NA,NA,NA,NA,NA,NA) , ncol=7 ) )
#( mat.char1 <- matrix(as.character(mat), ncol=7 ) )
#( dafr <- as.data.frame(mat) )

### no data argument
#removeNAcols()

### defaults
#removeNAcols(mat)
#removeNAcols(mat.char1)
#removeNAcols(dafr)

### not supported method
#removeNAcols( mat , method = "bla" )

### colnames
#removeNAcols( dafr , rows=c(1,2,3,4,5) )
#removeNAcols( dafr , rows=c("4","5","6") )
#removeNAcols( dafr , rows=list( c("item1","item2") , c(3,4,5)  ) )

### wrong rows argument
#removeNAcols( mat , rows=c("jklfs","kjkljl") )
#removeNAcols( mat , rows=list("jklfs","kjkljl") )

### wrong tolerance argument
#removeNAcols( mat , tolerance="1" )
#removeNAcols( mat , tolerance="dasfadsf" )

### preserve data.frame col classes
#( df <- data.frame( num = 1:5 , char = c("a","b","c","d","e") , numNA = rep(NA,5) , charNA = rep(as.character(NA),5) , stringsAsFactors = FALSE ) )
#class(df$num)
#class(df$char)
#( df2 <- removeNAcols ( df ) )
#class(df2$num)
#class(df2$char)
