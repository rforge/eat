# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# automateLme4Model
#
# Description: calls Functions to prepare, run and report lme4 Models
# Version: 	0.1.0
# Status: development
# Release Date: 	
# Author:    Sebastian Weirich
# Change Log:
#
# 2011-12-05 SW
# 0000-00-00 AA
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

### dataset         ... Datensatz als R-dataframe
### ID              ... Name oder Spaltennummer der ID-Variablen
### regression      ... optional: Variablen f�r das latente Regressionsmodell, entweder als Vektor mit Spaltennummern oder Variablennamen
### DIF             ... optional: DIF-Variable, entweder als Spaltennummer oder als Variablenname
### group.var       ... optional: Gruppenvariable(n), entweder als Vektor/Skalar mit Spaltennummern oder Variablennamen
### testitems       ... Spaltennummern oder Variablennamen der Testitems 
### person.grouping ... WIRD HIER NOCH NICHT VERARBEITET
### item.groping    ... Q-Matrix zur Spezifikation der Zugeh�rigkeit von Items zu latenten Dimensionen 
### m.model         ... WIRD HIER NICHT VERARBEITET
### anchor          ... optional: R-Dataframe mit Ankerparametern (1. Spalte: Variablenname, 2. Spalte: Verankerungsparameter)
### n.plausible     ... wieviele plausible values sollen gezogen werden?
### jobFolder       ... Verzeichnis f�r die Analyse

automateLme4Model <- function ( dataset, ID, regression=NULL, DIF=NULL, group.var=NULL, testitems, na=list(items=NULL, DIF=NULL, HG=NULL, group=NULL, weight=NULL), person.grouping=NULL, item.grouping=NULL,
                                    jobFolder, m.model="1pl", anchor=NULL, method=NULL, n.plausible=NULL, checkLink = FALSE, verbose = TRUE)	 {
    
  ver <- "0.1.0"
    ret <- TRUE
    if(missing(dataset)) {stop(paste("Error in automateLme4Model_",ver,": No dataset specified.\n",sep="")) }
    if(missing(ID))      {stop(paste("Error in automateLme4Model_",ver,": No ID specified.\n",sep="")) }
    if(length(DIF)>1)    {stop(paste("Error in automateLme4Model_",ver,": There can only be one DIF variable.\n",sep="")) }

	### Defaults
  if(is.null(n.plausible))     {n.plausible <- 5}
	
    ### Verzeichnisangaben d�rfen weder mit einem Schr�gstrich beginnen noch damit enden!
    if(!missing(jobFolder))
    ### entferne ggf. abschlie�ende Schr�gstriche
      {jobFolder <- crop(jobFolder,char = "/")}

	### 1. Datensatz f�r lme4 reshapen
		sunk(paste("automateLme4Model_",ver,": Prepare dataset for use in lme4.\n",sep=""))
		if(inherits(try( lme4Dataset <- genLme4Dataset ( dat=dataset, variablen= testitems, ID=ID, DIF.var=DIF, HG.var=regression, group.var=group.var, na=na,
                                                                 checkLink = checkLink)  ),"try-error"))
      { ret <- FALSE; sunk(paste("automateLme4Model_",ver,": Error in 'genLme4Dataset'. Data preparation for use in lme4 failed.\n",sep="")); stop()}
    
	### 2. Formelstatement f�r lme4 generieren
		sunk(paste("automateLme4Model_",ver,": Generate formula for lme4.\n",sep=""))
		if(inherits(try( lme4Formula <- genLme4Formula ( dat=dataset, variablen= testitems, ID=ID, DIF.var=DIF, HG.var=regression, group.var=group.var, na=na,
                                                                 checkLink = checkLink)  ),"try-error"))
      { ret <- FALSE; sunk(paste("automateLme4Model_",ver,": Error in 'genLme4Dataset'. Data preparation for use in lme4 failed.\n",sep="")); stop()}
    
	
	
    flush.console()
    return(lme4Dataset)}
    
