####################################################################################################################
#
# genLme4Dataset
# erzeugt lme4 Datensatz
# hervorgegangen aus prep.Conquest
#
# Version: 	0.1.0
# Depends:  reshape,
# Imports:
# Published:
# Author:   Sebastian Weirich
# Maintainer:
#
# Change Log:
#
# 2011-12-12 SW
# CHANGED: remove assign() from genConquestSynLab. table(unlist (...) ) replaced by table.unlist( ... )
# 0000-00-00 AA
#
#
####################################################################################################################

### dat          ... Datensatz als Datframe im Wideformat
### variablen    ... wo stehen Items im Datensatz, z.B. 5:120 oder -c(1:5)
### ID           ... wo steht ID-variable, entweder Spaltennummer oder Variablenname als String
### model        ... falls nicht definiert: eindimensional, ansonsten muss hier qmatrix uebergeben werden
###                  qmatrix als R-Dataframe; die spalte mit Itembezeichnung muss die Kennung "item" im
###                  Variablennamen haben, die Spalten mit den Dimensionen die kennung "dim"
### DIF.var      ... eine DIF-Variable, entweder als Spaltennummer oder Variablenname als String
### HG.var       ... ein oder mehrere Hintergrundvariablen, entweder als Spaltennummern oder Variablennamen,
###                  z.B. c(4,6), c("alter","geschlecht")
### anker        ... uebergeben wird R-Dataframe mit Ankerparametern.
###                  erwartet wird ein Dataframe mit zwei Spalten, eine mit Variablennamen, eine mit
###                  zu verankernden Parametern. Welche welche ist, wird darueber erkannt, ob die Spalte numerisch oder character ist.
### na           ... Liste mit Codes, die als NA zu behandeln sind, fuer Items und Hintergrundvariablen separat;
###                  z.B. na=list(items=c(6,7,8,9,96,97,98,99), DIF=9)

## genLme4Dataset <- function(zkdMasterDataset, variablen, ID, model=NULL, DIF.var=NULL, HG.var=NULL, anker = NULL, pfad=getwd(), name.analyse,name.dataset,pfad.dataset)

genLme4Dataset <- function(dat, variablen, ID, DIF.var=NULL, HG.var=NULL, group.var=NULL, na=list(items=NULL, DIF=NULL, HG=NULL, group=NULL, weight=NULL), verbose=TRUE,
                               model.statement="item", use.letters=FALSE, checkLink = FALSE)
                 {ver          <- "0.7.0"
                  nicht.erlaubt <-  c("mvi","mnr", "mci", "mbd", "mir", "mbi")
                  all.codes     <- unique(unlist(lapply(dat, FUN=function(ii) {names(table(ii))})))
                  if(!sum(nicht.erlaubt %in% all.codes ) == 0) {sunk(paste("genLme4Dataset_",ver,": Found uncollapsed missings in dataset: ",paste(nicht.erlaubt[which(nicht.erlaubt %in% all.codes)],collapse=", "),"\n",sep=""))
                                                                stop("Please run 'collapseMissings' for a start.\n")}
                  daten <- data.frame( dat[,variablen,drop=F], stringsAsFactors=FALSE)# Hier stehen erstmal NUR die Testitems. Diese werden nun, sofern spezifiziert, recodiert
                  if(!is.null(na$items)) 
                    {rec.items <- paste(na$items,"=NA",collapse="; ")           ### definiere recodierungsvorschrift
                     for (i in 1:ncol(daten))
                         {daten[,i] <- recode(daten[,i], rec.items)}}
				  if(checkLink == TRUE) {foo <- checkLink(daten)}
                  namen.items <- colnames(daten)
                  allVars     <- list(namen.hg.var=HG.var, namen.dif.var=DIF.var, namen.group.var=group.var)
                  all.Names   <- lapply(allVars, FUN=function(ii) {.existsBackgroundVariables(dat=dat,variable=ii)})
                  namen.hg.var <- all.Names$namen.hg.var
                  namen.dif.var <- all.Names$namen.dif.var
                  namen.group.var <- all.Names$namen.group.var
                  ### for (ii in seq(along=all.Names)) {assign(names(allVars)[ii], all.Names[[ii]])}
                  ### Conquest erlaubt keine expliziten Variablennamen, die ein "." oder "_" enthalten
                  namen.all.hg.vars <- list(namen.hg.var=namen.hg.var, namen.dif.var=namen.dif.var, namen.group.var=namen.group.var)
                  
				  for (ii in seq(along=namen.all.hg.vars)) {assign(names(namen.all.hg.vars)[ii], namen.all.hg.vars[[ii]])}
                  ### Dif-Variablen und Testitems duerfen sich nicht ueberschneiden
                  if(length(intersect(namen.dif.var, namen.items))>0) {stop(paste("genLme4Dataset_",ver,": Testitems and DIF variable overlap.\n",sep=""))}
   
                  ### HG-Variablen und Testitems duerfen sich nicht ueberschneiden
                  if(length(intersect(namen.hg.var, namen.items))>0) {stop(paste("genLme4Dataset_",ver,": Testitems and HG variables overlap.\n",sep=""))}
                  
                  ### group Variablen und Testitems duerfen sich nicht ueberschneiden
                  if(length(intersect(namen.group.var, namen.items))>0) {stop(paste("genLme4Dataset_",ver,": Testitems and group variables overlap.\n",sep=""))}
                                    
                  ### geprueft wird: enthaelt IRGENDEIN Testitem gar keine gueltigen Werte?
                  n.werte <- lapply(1:ncol(daten), FUN=function(ii) {table(daten[,ii])})
                  options(warn = -1)                                            ### zuvor: schalte Warnungen aus!
                  only.null.eins <- unlist( lapply(n.werte, FUN=function(ii) {all( names(ii) == c("0","1") ) }) )
                  options(warn = 0)                                             ### danach: schalte Warnungen wieder an!
                  n.werte <- sapply(1:length(n.werte), FUN=function(ii) {length(n.werte[[ii]])})
                  n.mis   <- which(n.werte == 0)
				          namen.items.weg <- NULL
                  if(length(n.mis) >0) {sunk(paste("genLme4Dataset_",ver,": Serious warning: ",length(n.mis)," testitems(s) without any values.\n",sep=""))
                                        if(verbose == TRUE) {sunk(paste(colnames(daten)[which(n.werte == 0)], collapse=", ")); sunk("\n") }
                                        stop()										
                                       }
                  n.constant <- which(n.werte == 1)
                  if(length(n.constant) >0) {sunk(paste("genLme4Dataset_",ver,": Warning: ",length(n.constant)," testitems(s) are constants.\n",sep=""))
                                             if(verbose == TRUE) {foo <- lapply(n.constant,FUN=function(ii) {sunk(paste(colnames(daten)[ii],": ",names(table(daten[,ii])),sep="")); sunk("\n")})}
											stop()
											}
                  n.rasch   <- which( !only.null.eins )
                  if(length(n.rasch) >0 )   {sunk(paste("genLme4Dataset_",ver,": Warning: ",length(n.rasch)," variable(s) are not strictly dichotomous with 0/1.\n",sep="")) }
                  
                  ### identifiziere Faelle mit ausschliesslich missings
                 all.values   <- table(unique(unlist(lapply(1:ncol(daten), FUN=function(ii) {names(table(daten[,ii]))}))))
                  if(length(all.values)!=2) {sunk(paste("genLme4Dataset_",ver,": Warning: Found more than two non missing codes in overall testitems. Data does not seem to fit to the Rasch model.\n",sep=""))}
                  if(length(all.values)==2) {if(!all(names(all.values) == c("0","1"))) {sunk("Warning: Found codes departing from 0 and 1 in testitems. Data does not seem to fit to the Rasch model.\n")}}
                  weg.variablen <- rowSums(is.na(daten))                        ### identifiziere F�lle mit ausschlie�lich missings
                  weg.variablen <- which(weg.variablen == ncol(daten))
                  if(length(weg.variablen)>0) 
                    {sunk(paste("genLme4Dataset_",ver,": Found ",length(weg.variablen)," cases with missings on all items.\n",sep=""))}
 				          if(!is.null(HG.var))
                    {if(!is.null(na$HG))                                        ### bevor irgendwas anderes geschieht, werden, sofern spezifiziert, die HG-Variablen recodiert
                       {rec.hg <- paste(na$HG,"=NA",collapse="; ")              ### definiere recodierungsvorschrift
                        for (i in 1:ncol(dat[,namen.hg.var,drop=F]))
                            {dat[,namen.hg.var[i]] <- recode(dat[,namen.hg.var[i]], rec.hg)}}## untere Zeile: wieviele "character" haben Hintergrundvariablen?
                     mis     <- sapply(1:length(namen.hg.var), FUN=function(ii) {length(table(dat[,namen.hg.var[ii]]))})
                     mis.1   <- which(mis == 0)
                     if(length(mis.1)>0) {stop(paste("genLme4Dataset_",ver,": At least one HG-variable without any values.",sep=""))}
                     mis.2   <- which(mis == 1)
                     if(length(mis.1)>0) {sunk(paste("genLme4Dataset_",ver,": Warning: At least one HG-variable is a constant.\n"))}
                     num     <- unlist(lapply(1:length(namen.hg.var),FUN=function(ii) {length( unique(c(grep("[[:digit:]]",dat[,namen.hg.var[ii]]),which(is.na(dat[,namen.hg.var[ii]])))))}))
                     if(!all(num==nrow(dat)))                                   ### HG-Variablen m�ssen numerisch sein, das will conquest so. F�r diese Pr�fung sind also NA und numerische Werte erlaubt
                       {sunk(paste("genLme4Dataset_",ver,": Warning: Found ",length(which(num!=nrow(dat)))," HG variable(s) with non missing non-numeric values. lme4 will handle these variable(s) as factors.\n",sep=""))
                        if(verbose==TRUE) {sunk(paste( namen.hg.var[which(num!=nrow(dat))],collapse=", ")); sunk("\n")}}
                     mis.spec <- unlist(lapply(1:length(namen.hg.var), FUN=function(ii) { sum(is.na(dat[,namen.hg.var[ii]]))}))
                     if(!all(mis.spec==0))                                      ### auf welchen HG-Variablen gibt es wieviele missings?
                       {sunk(paste("genLme4Dataset_",ver,": Warning: Found ",length(which(mis.spec!=0))," HG variable(s) with missing value(s). \n",sep=""))
                        if(verbose==TRUE) {sunk(paste( namen.hg.var[which(mis.spec!=0)],collapse=", ")); sunk("\n") } }
                     dat.hg  <- data.frame(dat[,namen.hg.var,drop=F],stringsAsFactors=F)
                     weg.hg  <- attr(na.omit(dat.hg), "na.action")
                     # if(length(weg.hg)>0)
                     #  {cat(paste("Remove ",length(weg.hg)," cases with missings on HG variables.\n",sep=""))}
                    }
					   
                  if(!is.null(group.var))  {                                       
                     if(!is.null(na$group))                                     ### bevor irgendwas anderes geschieht, werden, sofern spezifiziert, die HG-Variablen recodiert
                       {rec.group <- paste(na$group,"=NA",collapse="; ")        ### definiere recodierungsvorschrift
                        for (i in 1:ncol(dat[,namen.group.var,drop=F]))
                            {dat[,namen.group.var[i]] <- recode(dat[,namen.group.var[i]], rec.group)}}
                     ### missings auf Gruppenvariablen?
                     mis.group <- unlist( lapply(1:length(namen.group.var), FUN=function(ii){sum(is.na(dat[,namen.group.var[ii]]))}))
                     if(!all(mis.group==0))
                       {sunk(paste("genLme4Dataset_",ver,": Warning: Found ",length(which(mis.group!=0))," group variable(s) with missing value(s). \n",sep=""))
                        sunk(paste( namen.group.var[which(mis.group!=0)],collapse=", ")); sunk("\n") }
                    }
                  
                   if(!is.null(DIF.var))  {
                     if(length(DIF.var)!=1) {stop("Use only one DIF-variable.")}
                     if(!is.null(na$DIF))                                       ### bevor irgendwas anderes geschieht, werden, sofern spezifiziert, die DIF-Variablen recodiert
                       {rec.dif <- paste(na$DIF,"=NA",collapse="; ")            ### definiere recodierungsvorschrift
                        dat[,namen.dif.var] <- recode(dat[,namen.dif.var], rec.dif)}
                     if(length(table(dat[,namen.dif.var])) == 0) {stop("No valid values in DIF variable.")}
                     DIF.char <- max(nchar(as.character(na.omit(dat[,namen.dif.var]))))
                     if(length(table(dat[,namen.dif.var]))!=2) {sunk("Serious problem: DIF-variable does not seem to be dichotomous.\n")}
                     weg.dif <- which(is.na(dat[,namen.dif.var]))
                       if(length(weg.dif)>0)                                      ### untere Zeile: dies geschieht erst etwas spaeter, wenn datensatz zusammengebaut ist
                       {sunk(paste("genLme4Dataset_",ver,": Found ",length(weg.dif)," cases with missings on DIF variable.\n",sep=""))}
					           ### gepr�ft werden Testitems: keine Werte? konstant? aber diesmal f�r DIF-Gruppen getrennt
                     n.werte <- lapply(daten, FUN=function(ii){by(ii, INDICES=list(dat[,namen.dif.var]), FUN=table)})
                     completeMissingGroupwise <- data.frame(t(sapply(n.werte, function(ll){lapply(ll, length)})), stringsAsFactors = FALSE)
                     for (i in seq(along=completeMissingGroupwise)) {
                          missingCat.i <- which(completeMissingGroupwise[,i] == 0)
                          if(length(missingCat.i) > 0) {
                             sunk(paste("genLme4Dataset_",ver,": Warning: Following items with no values in DIF group ",i,": \n",sep=""))
                             sunk(paste(rownames(completeMissingGroupwise)[missingCat.i],collapse=", ")); sunk("\n")
                          }
                          constantCat.i <- which(completeMissingGroupwise[,i] == 1)
                          if(length(constantCat.i) > 0) {
                             sunk(paste("genLme4Dataset_",ver,": Warning: Following items are constants in DIF group ",i,":\n",sep=""))
                             sunk(paste(rownames(completeMissingGroupwise)[constantCat.i],collapse=", ")); sunk("\n")
                          }
                     }
                   }
                  namen.all.hg <- unique(c(namen.dif.var,namen.hg.var,namen.group.var))## Achtung: group- und DIF- bzw. group- und HG-Variablen duerfen sich ueberschneiden!
                  if(!is.null(namen.all.hg)) {all.hg.char <- sapply(1:length(namen.all.hg), FUN=function(ii) {max(nchar(as.character(na.omit(dat[,namen.all.hg[ii]]))))})}
                  daten <- data.frame(ID=as.factor(dat[,ID]), dat[,namen.all.hg,drop=F], daten, stringsAsFactors=F)
                  dat.labels <- data.frame( dat[,variablen],stringsAsFactors=F)
                  if(!is.null(namen.items.weg))                             ### umst�ndlich: ich muss hier nochmal die Itemnamen holen (ausschlie�lich der ggf. entfernten Items)
                     {dat.labels <- dat.labels[,-match(namen.items.weg,colnames(dat.labels))]}
                  dat.long        <- melt.data.frame(data=daten, id.vars=c("ID",namen.all.hg), measure.vars=colnames(dat.labels), na.rm=T)
                  dat.long$ID    <- as.factor(dat.long$ID)
                  return(list(dat.long = dat.long, namen.items=namen.items, namen.hg.var=namen.hg.var, namen.dif.var=namen.dif.var,namen.group.var=namen.group.var))
                  }  

                  
				  
				  

