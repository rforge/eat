####################################################################################################################
#
# get.wle
# liest Conquest-Personenparameterfiles (*.wle) als R-Objekte ein
# Funktion eignet sich sowohl f�r Dateien, die WLEs als auch MLEs enthalten
#
# Version: 	1.2.0
# Depends: gdata
# Imports:
# Published:
# Author:  Sebastian Weirich
# Maintainer:
#
# Change log:
# 2011-11-30 SW
# FIXED: problem with multidimensional WLEs and first cases without answers re-repaired
# 0000-00-00 AA
# 30.11.2011, SW: problem with multidimensional WLEs and first cases without answers re-repaired
#                 (conventions in Version, 1.1.0, Archiv)
# 25.11.2011, SW: 'cat' durch 'sunk' ersetzt
# 03.10.2011, NH:  zu 1.0.0 (Benennungen Input und Output ge�ndert, entsprechen jetzt ZKD-Konvention
# 08.08.2011 MH: auf stable gesetzt wegen besserer sourcebarkeit
# 30.12.2010, SW: korrekte Benennung der Spalten auch bei WLE-Dateien 
#                 mit integrierter ID
# 20.12.2010, SW: Funktion erm�glicht auch das Auslesen von WLE-Dateien 
#                 mit integrierter ID
#
####################################################################################################################

get.wle <- function (file) {
    funVersion <- "get.wle_1.2.0"
    input <- readLines (file)
    input <- crop(input)
    input <- strsplit(input, " +")

    n.spalten <- max ( sapply(input,FUN=function(ii){ length(ii) }) )
    n.wle <- (n.spalten-1) / 4                                          ### Spaltenanzahl sollte ganzzahlig sein.
    input <- data.frame( matrix( t( sapply(input,FUN=function(ii){ ii[1:n.spalten] }) ),length(input),byrow=F), stringsAsFactors=F)
    options(warn = -1)                                                  ### Warnungen aus
    n.na  <- which(rowSums(is.na(input)) == 0)[1]
		if(length(n.na)==0) {stop(paste(funVersion,": Cannot identify columns in wle file.\n",sep=""))}
		num   <- as.numeric(input[n.na,])                                   ### welche Spalten kann man numerisch formatieren?
    num   <- which(!is.na(num))
    options(warn = 0)

ind <- rowSums(is.na(input))                                     ### suche Zeile mit maximaler Anzahl nicht fehlender Elemente
               ind <- which(ind == min(ind))[1]
               options(warn = -1)                                               ### zuvor: schalte Warnungen aus!
               ind.1 <- as.numeric(input[ind,])                                 ### wo stehen in dieser Spalte Zahlen?
               ind.1 <- which(!is.na(ind.1))                                    ### hier stehen Zahlen!
               for (ii in ind.1) {input[,ii] <- as.numeric(input[,ii])}         ### mache numerisch, wo es geht!
               options(warn = 0)                                                ### Warnungen ein!
               ind.2 <- sapply(ind.1,FUN=function(ii){ input[ind,ind.1[ii]] == round(input[ind,ind.1[ii]],digits=0)})  ### wo stehen reelle Zahlen (KEINE ganzen Zahlen?)
               ind.2 <- ind.1[!ind.2]                                           ### hier stehen WLEs! length(ind.2)/2 = Anzahl der WLEs = Anzahl der Dimensionen
               cat(paste(funVersion,": Found valid WLEs of ", nrow(na.omit(input))," person(s) for ", length(ind.2)/2, " dimension(s).\n",sep=""))
               namen.1 <- as.vector( sapply(1:(length(ind.2)/2),FUN=function(ii){c("n.solved","n.total")}))
               namen.2 <- as.vector( sapply(1:(length(ind.2)/2),FUN=function(ii){c("wle","wle.se")}))
               namen.1 <- paste(namen.1,rep(1:(length(namen.1)/2),each=2),sep=".")# obere Zeile: benenne nun!
               namen.2 <- paste(namen.2,rep(1:(length(namen.2)/2),each=2),sep=".")
               namen   <- c(namen.1,namen.2)
               colnames(input)[1:2] <- c("case","ID")
               colnames(input)[(ncol(input)- length(namen)+1): ncol(input)] <- namen
               
return(input)}
               
