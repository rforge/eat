# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# .automateModels.runBatches
# Description: Subroutine von automateModels
# Version: 	0.2.0
# Status: beta
# Release Date: 	2011-10-14
# Author:    Martin Hecht
# Change Log:
#		14.10.2011 MH: Ausgaben auf Englisch
#		08.09.2011 MH: cat durch sunk ersetzt (f�r Logfile)
#			
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.automateModels.runBatches <- function ( batches , run.mode ) {
		
		# Funktionsname f�r Meldungen
		f. <- ".automateModels.runBatches"
		f.n <- paste ( f. , ":" , sep = "" )
		
		# Plausichecks
		stopifnot ( run.mode %in% c ( "serial" , "parallel" ) )
		if ( !length ( batches ) == 1 & run.mode == "serial" ) {
				# sunk ( paste ( f.n , " run.mode ist 'serial', aber es existiert mehr als eine Batch-Datei. d.h. somethin' wrong.\n" , sep = "" ) )
				sunk ( paste ( f.n , " run.mode is 'serial', but more than one batch file exists, that means somethin' wrong.\n" , sep = "" ) )
				stop ( )
		}
		
		# Batch starten wenn run.mode == "serial" , bei "parallel" Prompt an User
		if ( run.mode == "serial" ) {
	
				# 14.10.2011 rausgenommen, Package wird auf mind. 2.13.1 gesetzt
				# sunk ( paste ( "\n" , f.n , "\n" , 
							  # "F�r einige R-Versionen ( 2.12.1 , 2.12.2 , teilweise 2.13.0 )\n" , 
							  # "funktioniert der Aufruf von externen Programmen ( z.B. ConQuest )\n" , 
							  # "nicht oder ist fehlerhaft.\n" ,
							  # "Bitte unbedingt pr�fen, ob ConQuest startet ( z.B. im Systemmonitor )\n" ,
							  # "Falls ConQuest nicht automatisch startet, bitte manuell starten.\n" ,
							  # "Diese R-Version: " , R.Version()$version.string , "\n\n" , sep = "" ) )
	
				#command <- normalizePath ( unlist ( batches ) , mustWork=TRUE )
				command <- unlist ( batches ) 
								
				# sunk ( paste ( f.n , " Versuche " , command , "\n                            an die Konsole abzusetzen ... " , sep = "" ) )
				sunk ( paste ( f.n , " Try sending " , command , "\n                            to console ... " , sep = "" ) )
				
				rtrn <- system ( command ,
								 intern = FALSE ,
								 ignore.stdout = FALSE ,
								 ignore.stderr = FALSE ,
								 wait = FALSE ,
								 input = NULL ,
								 show.output.on.console = FALSE ,
								 minimized = FALSE ,
								 invisible = FALSE )
				
				if ( rtrn == 0 ) {
								sunk ( paste ( "done.\n\n" , sep = "" ) )
								ret <- TRUE
						} else {
								sunk ( paste ( "Error.\n" , sep = "" ) )
								# sunk ( paste ( f.n , " " , command , " konnte NICHT gestartet werden.\n" , sep = "" ) )
								sunk ( paste ( f.n , " " , command , " could NOT be started.\n" , sep = "" ) )
								stop ( )
								ret <- FALSE
						}
	
		} else if ( run.mode == "parallel" ) {
				
				# sunk ( paste ( f.n , " Bitte folgende Batch-Dateien MANUELL STARTEN:\n" , sep = "" ) )
				sunk ( paste ( f.n , " Please MANUALLY START these batch file(s):\n" , sep = "" ) )
				muell <- mapply ( function ( batches ) {
						sunk ( paste ( "                            " , batches , "\n" , sep = "" ) )
				} , batches )
				
				ret <- TRUE
				
		} else {
				ret <- FALSE
		}
	
		# returnen 
		return ( ret )
		
}



