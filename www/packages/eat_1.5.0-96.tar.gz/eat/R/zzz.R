.First.lib <- function(lib, pkg){
	packageStartupMessage ( paste ( "\neat version: 1.5.0-96 (2012-03-29)\nThis version is BETA. Use at your own risk.\n" ) )
}
