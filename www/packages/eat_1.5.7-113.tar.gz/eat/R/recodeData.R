# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# recodeData - formerly known as zkdDatasetRecode
#
# function:    recodeData (dat, values, subunits)
#
# Description: rekodiert Datens�tze
# 
# arguments: 
#     dat (data.frame)      ... Datensatz mit ID-Variablen und (mindestens) allen Variablen, die rekodiert werden sollen
#     values (data.frame)   ... ZKD-Inputtabelle f�r Codes, siehe P:\ZKD\01_Organisation\Konzepte\InputStruktur_Konzept.xlsx             
#     subunits (data.frame) ... ZKD-Inputtabelle f�r Subunits (Subitems), siehe P:\ZKD\01_Organisation\Konzepte\InputStruktur_Konzept.xlsx   
#
# Version: 	1.1.0
# Status: alpha
# Release Date: 	2011-08-02
# Author: 	Martin Hecht , Christiane Penk
# depends: package car
#          Funktionen aus makeInput
#          Funktion sunk aus Package automateModels
#
# Change Log:
# * 1.1.0  (2011-11-23, ZKD) stabilisiert
# * 1.0.1 (2011-11-21, KS) auch positive R�ckmeldung (welche Var rekodiert)
# * 1.0.0 (2011-11-03, NH) �berarbeitet und auf neue ZKD-Inputtabellen angepasst, 
#               �berfl�ssig gewordene Checks rausgenommen 
#
# 02.08.11 "mbd" aus Pr�fung auf unvollst�ndige Rekodierungsvorschrift rausgenommen
# 12.07.11 kein Abbruch bei unvollst�ndigen Rekodierungsvorschriften, nur Warnung
# 01.07.11 Unvollst�ndige Rekodierungsvorschrift:
#				bugfix
#				Ausgabe f�r welche Werte ( je Variable ) die Rekodierungsvorschriften fehlt
#				Abbruch bei unvollst�ndigen Rekodierungsvorschriften
# 24.05.11 Anpassungen nach zkd-Sitzung
#			f�r zu rekodierende Variablen:	
#				Der Variablen-Typ (nach neuer Def.) wird durchgeschleift.
#				Das Transformationsniveau wird auf entsprechenden Wert gesetzt.
#				Das Value-Label rekodierter Variablen wird gel�scht.
#				Plausicheck: bei surjektiven Abbildungen mit missings stoppt Funktion (Fall nicht vorgesehen)
#			nicht zu rekodierende Variablen werden (wie bisher) durchgeschleift
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#-----------------------------------------------------------------------------------------

recodeData <- function (dat, values, subunits) {
  funVersion <- "recodeData_1.0.1: "

  if (class(dat) != "data.frame") {
  stop (paste(funVersion, "'dat' must be a data.frame.", sep = ""))
  }  

  recodeinfo <- makeInputRecodeData (values = values, subunits = subunits)
  
  # make recoded data.frame
  datR <- data.frame(mapply(.recodeData.recode, dat, 
  colnames(dat), MoreArgs = list(recodeinfo), USE.NAMES = TRUE), 
  stringsAsFactors = FALSE)
  
  colnames(datR) <- sapply(colnames(datR), .recodeData.renameIDs, recodeinfo, USE.NAMES = FALSE)
  
  return(datR)
}

#-----------------------------------------------------------------------------------------

.recodeData.recode <- function (variable, variableName, recodeinfo) {
  variableRecoded <- NULL
  funVersion <- "recodeData_1.0.1: "
  
  if (!(class(variable) == "character")) { 
    variable <- as.character(variable)
  }
  
  if (is.null(recodeinfo[[variableName]]$values)) {
    variableRecoded <- variable
    sunk(paste(funVersion, "Found no recode information for variables ", variableName, ". These variables will not be recoded.", sep =""))
  } else {
    dontcheck <- c("mbd")
    variable.unique <- na.omit(unique(variable[which(!variable %in% dontcheck)]))
    recodeinfoCheck <- (variable.unique %in% names(unlist(recodeinfo[[variableName]]$values)))
    if (!all(recodeinfoCheck == TRUE)) {
      sunk(paste(funVersion, "Incomplete recode information for variable ", 
      variableName, ". Value(s) ",  
      paste(sort(variable.unique[!recodeinfoCheck]), collapse = ", "), " will not be recoded.", sep = ""))
    }
    
    recodeString <- paste(paste("'", names(unlist(recodeinfo[[variableName]]$values)), 
    "'", "=", "'", unlist(recodeinfo[[variableName]]$values), "'", 
    sep = ""), collapse = "; ")
    variableRecoded <- recode(variable, recodeString, as.factor.result = FALSE, 
    as.numeric.result = FALSE)
	sunk(paste(funVersion, variableName, " has been recoded.", sep =""))
  }
  return(variableRecoded)
}

#-----------------------------------------------------------------------------------------

.recodeData.renameIDs <-  function(colname, recodeinfo) {
  newID <- recodeinfo[[colname]]$newID
  if (is.null(newID)) {
   colname
  } else {
    newID
  }
}