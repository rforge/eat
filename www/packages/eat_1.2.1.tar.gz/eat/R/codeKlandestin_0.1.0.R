####################################################################################################################
#
# Sammlung von Code, den nie niemand zu Gesicht bekommen sollte 
#
# Version: 	0.1.0
# Depends: 	
# Imports: 	
# Published: 	2011-08-08
# Author: 	Martin Hecht
# Maintainer: 	Martin Hecht
#
# Change-Log
# 08.08.2011 MH: auf stable gesetzt wegen besserer sourcebarkeit
# 24.01.2011 MH		option "cumulate" added
# 21.01.2011 MH
# 15.01.2011 MH
#
####################################################################################################################

# "Mutter"-Funktion zu removeNArows und removeNAcols
# mode ("rows" oder "cols") hinzugef�gt um entsprechende Warnmeldungen zu bekommen
removeNA <- function( data , cols , tolerance , cumulate , method , warn , mode="rows" ) {
		
		# mode check
		if ( ! (mode %in% c("rows", "cols") ) ) stop ( paste ( "internal error: mode \"" , mode , "\" is not supported" , sep="" ) )		
		
		# method check
		if ( ! (method[1] %in% c("remove", "identify") ) ) stop ( paste ( "method \"" , method , "\" is not supported" , sep="" ) )

		# cumulate / warn check
		if ( ! ( is.logical(cumulate) ) ) stop ( paste ( "'cumulate' is not logical" , sep="" ) )
		if ( ! ( is.logical(warn) ) ) stop ( paste ( "'warn' is not logical" , sep="" ) )				
		
		# wenn Matrix, diese in Dataframe wandeln, f�r sp�ter merken ob Matrix zur�ckgegeben werden soll
		returnMatrix <- FALSE
		if (is.matrix(data)) { data <- as.data.frame(data) ; returnMatrix <- TRUE }

		# wenn nicht Dataframe, dann stoppen
		if ( !is.data.frame(data) ) stop ( "'data' is not a matrix or data.frame" )

		# wenn Dataframe leer, dann stoppen
		if ( identical ( data, data.frame() ) ) stop ( "data.frame 'data' is empty" )

		# wenn nicht mindestens eine Zeile, stoppen
		if ( nrow(data) < 1 ) {	
				mes <- "row"
				if ( mode == "cols" ) mes <- "column"
				stop ( paste("data.frame 'data' has less than 1", mes) )
		}	
		
		# cols validieren
		modeForVal <- "cols"
		if ( mode=="cols" )	modeForVal <- "rows"
		cols <- validateCols ( data , cols , modeForVal )
		
		# wenn tolerance keine List dann eine draus machen
		if (!class(tolerance)=="list") { tolerance <- list(tolerance) }		

		# wenn tolerance nicht numerisch, stoppen
		lapply ( tolerance , function (tolerance) { 
						if (!(class(tolerance)=="integer"||class(tolerance)=="numeric")) stop (paste("tolerance is not numeric, but",class(tolerance)))
				} ) 
		
		# tolerance an cols anpassen (recyclen oder abschneiden)
		if (length(cols)>length(tolerance)) { tolerance <- rep(tolerance, (length(cols) %/% length(tolerance)) + 1) }		
		if (length(cols)<length(tolerance)) { tolerance <- tolerance[seq(along=cols)] }

		# zu l�schende rows identifizieren
		# wenn nur eine Spalte, dann nicht mit rowSums (erzeugt Fehler), sonst mit rowSums
		rows.rm.list <- NULL
		rows.rm.list <-	mapply(
						function(cols,tolerance) {
							if ( ncol(data[,cols, drop=FALSE]) == 1 ) {
									rows.rm.list <- which ( is.na(data[,cols,drop=FALSE]) )
							} else { 
										if (cumulate) rows.rm.list <- unname ( which ( rowSums( !is.na( data[ , cols ] ) ) <= tolerance ) )
										else rows.rm.list <- unname ( which ( rowSums( !is.na( data[ , cols ] ) ) == tolerance ) )
									}
						}
						, cols, tolerance , SIMPLIFY=FALSE)

		# zu l�schende Zeilen
		rows.rm <- NULL
		rows.rm <- unique ( unlist ( rows.rm.list ) ) 						
						
		if (method[1]=="remove") {
		
				# Zeilen l�schen
				if (! ( identical( rows.rm , integer(0) ) || is.null(rows.rm) ) ) {
						data <- data[-rows.rm , , drop=FALSE]
						if (warn) { 
								mes <- "row(s)"
								if ( mode == "cols" ) mes <- "column(s)"
								warning( paste ( mes , paste(rows.rm, collapse=", ") , "was/were dropped") )
						}
				}
				
				# falls Matrix als Input, in Matrix zur�ckwandeln
				if (returnMatrix) { data <- unname( as.matrix(data) ) }
				
				return ( data )
				
		} else if (method[1]=="identify") {
						
						# Liste oder Vector mit identifizierten Rows zur�ckgeben
						if (length(rows.rm.list) == 1) return ( sort ( rows.rm ) )
						else return ( rows.rm.list ) 

				} else { return ( NULL ) }
}



# Spalten-Spezifikation und Spalten-Subsets checken
# wandelt character colnames in spaltennummern
# bringt warnungen wenn spalten nicht in datensatz und droppt diese
# returned ne Liste mit validierten Spalten-Subsets
# mode gibt an ob in Warnmeldungen von columns oder rows die Rede ist
validateCols <- function ( data , cols , mode="cols" ) {

		# mode check
		if ( ! (mode %in% c("rows", "cols") ) ) stop ( paste ( "internal error: mode \"" , mode , "\" is not supported" , sep="" ) )		

		# wenn cols nicht angegeben, dann alle Columns
		if (is.null(cols)) cols <- seq( along=colnames(data) )		

		# wenn cols keine Liste dann eine draus machen
		if (!class(cols)=="list") { cols <- list(cols) }

		# character zu numeric
		# numerische spalten nummern; Spalten, die nicht existieren, raus
		cols.num <- lapply ( cols, function (cols, colnames) {
					if ( class(cols)=="character" ) which( colnames %in% cols )
					else if ( class(cols)=="numeric" || class(cols)=="integer" ) cols [ which ( abs(cols) %in% seq(along=colnames) ) ]
					else return(NULL)
				}
				, colnames(data) )	

				
		lapply ( cols, function (cols, colnames) {
					if ( class(cols)=="character" ) which( colnames %in% cols )
					else if ( class(cols)=="numeric" || class(cols)=="integer" ) cols [ which ( seq(along=colnames) %in% abs(cols) ) ]
					else return(NULL)
				}
				, colnames(data) )	
		
		# Warnungen		
		mes <- "column"
		if (mode=="rows") mes <- "row"
		mapply ( function( cols, cols.num ) {
					if ( ( dif <-  length ( cols ) - length ( cols.num ) ) == 0 ) return (cols.num)
					else if ( identical ( cols.num , integer(0) ) ) {
									warning ( paste ( mes, " subset \"", paste(cols,collapse=", "), "\" is empty or misspecified and has been dropped"  , sep="") )
									return (cols.num)
							} else if ( ! ( dif == 0) ) {
												warning ( paste ( dif , " element(s) in ",mes," subset \"", paste(cols,collapse=", "), "\" is/are misspecified and dropped" , sep="") )
												return (cols.num)
										} else return(NULL)			
				}
				, cols , cols.num )

		# Subsets, die leer sind, raus
		cols.num <- cols.num[which( sapply ( cols.num , function (cols.num) { ! (is.null(cols.num)||identical(cols.num,integer(0))||identical(cols.num,numeric(0))) } ) ) ]
		
		return(cols.num)
}
### T e s t
#mat <- matrix( c( 1,1,1,1,1, 1,1,1,1,NA, 1,1,1,NA,NA, 1,1,NA,NA,NA, 1,NA,NA,NA,NA, NA,NA,NA,NA,NA ) , ncol=5 , byrow=TRUE )
#dafr <- as.data.frame(mat)
#( cols <- list("V1", c("V2","V3") , c("V2","V3","adsff") , c(1,2,3,4) , c("sdfaf") , c(6,7) , c(-1) , NULL) )
#( cols <- c(1,2,3) )
#( validateCols ( dafr , cols )	)


