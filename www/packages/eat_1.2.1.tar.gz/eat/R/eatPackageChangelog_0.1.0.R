# 2011-12-12 MH
# FIXED: no visible global function definition for 'get.item.par', 'get.person.par', 'yen.q3', '.q3.to.structure'
# 0000-00-00 AA

