### R code from vignette source 'eatRep.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
library(fmsb)
library(eatData)
library(eatRep)


###################################################
### code chunk number 2: reading_writingdef
###################################################
str(reading_writing)


###################################################
### code chunk number 3: readingMeansByCountrydef
###################################################
means <- jk2.mean(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", JKZone = "JKZone", 
         JKrep = "JKrep", groups = list(federalState = "country"), 
         dependent = list(reading = c("reading_score1", "reading_score2", "reading_score3")))


###################################################
### code chunk number 4: readingMeansByCountryResultsdef
###################################################
means[c(1:4,19:20),]


###################################################
### code chunk number 5: readingMeansByCountryResultsdefSummary
###################################################
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 6: readingMeansByCountry2def
###################################################
means <- jk2.mean(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", 
      groups = list(federalState = "country"), 
	  dependent = list(reading = c("reading_score1", "reading_score2", "reading_score3")))
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 7: readingMeansByCountry3def
###################################################
means <- jk2.mean(dat = reading_writing, ID = "idstud", groups = list(federalState = "country"), 
	  dependent = list(reading = c("reading_score1", "reading_score2", "reading_score3")))
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 8: readingMeansByCountry4def
###################################################
means <- jk2.mean(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", JKZone = "JKZone", 
         JKrep = "JKrep", groups = list(federalState = "country", gender = "sex"), 
         group.splits = c(0,2), group.differences.by = "gender", 
	  dependent = list(reading = c("reading_score1", "reading_score2", "reading_score3")))


###################################################
### code chunk number 9: readingMeansByCountry5def
###################################################
dM(means, omitTerms = c("var","Ncases", "NcasesValid"))


###################################################
### code chunk number 10: readingWriting2def
###################################################
reading_writing[1:5,19:23]


###################################################
### code chunk number 11: hiseiFreqsByCountryGenderdef
###################################################
freqs <- jk2.table(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", 
      JKZone = "JKZone", JKrep = "JKrep", 
	  groups = list(federalState = "country", gender = "sex"), 
	  dependent = list(Hisei = paste("zehisei",1:5,sep="")))
dT(freqs)


###################################################
### code chunk number 12: redefineValues1def
###################################################
reading_writing2 <- reading_writing
reading_writing2[which(reading_writing2[,"zehisei1"] == 5),"zehisei1"] <- 4
reading_writing2[which(reading_writing2[,"zehisei2"] == 5),"zehisei2"] <- 4


###################################################
### code chunk number 13: redefineValues2def
###################################################
cols <- paste("zehisei", 2:4, sep = "")
for (i in cols) {
     casesToNA <- sample(x = c(1:nrow(reading_writing2)), size = 12, replace = FALSE )
     reading_writing2[ casesToNA ,i ] <- NA
}


###################################################
### code chunk number 14: redefineValuesdef
###################################################
freqs2 <- jk2.table(dat = reading_writing2, ID = "idstud", wgt = "wgtSTUD",
      separate.missing.indikator = TRUE, JKZone = "JKZone", JKrep = "JKrep", 
	  groups = list(federalState = "country", gender = "sex"), 
	  dependent = list(Hisei = paste("zehisei",1:5,sep="")))
dT(freqs2)


###################################################
### code chunk number 15: regression1def
###################################################
mod1  <- jk2.glm(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", JKZone = "JKZone",
         JKrep = "JKrep", groups = list(country = "country"),
         dependent = list(reading = paste("reading_score", 1:3, sep = ""),
                          writing = paste("writing_score", 1:3, sep = "")),
         independent = list(gender = "sex", INCOME = c("income1", "income2")),
         complete.permutation = "no", glm.family = gaussian(link="identity") )


###################################################
### code chunk number 16: regression1defResults1
###################################################
dG(mod1, analyses = 1:2)


###################################################
### code chunk number 17: regression2def
###################################################
mod1  <- jk2.glm(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", JKZone = "JKZone",
         JKrep = "JKrep", dependent = list(gender = "sex"),
         independent = list(federalState = "country") ,
         complete.permutation = "no", glm.family = binomial(link="logit") )
dG(mod1)


###################################################
### code chunk number 18: transformdef
###################################################
exp(mod1[3:5,"value"])


###################################################
### code chunk number 19: recodeSexdef
###################################################
library(car)
reading_writing[,"sexRecoded"] <- car::recode(reading_writing[,"sex"], "'male' = '_male'")


###################################################
### code chunk number 20: regressionReplicationdef
###################################################
mod1  <- jk2.glm(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", JKZone = "JKZone",
         JKrep = "JKrep", groups = list(country = "country"),
         dependent = list(reading = paste("reading_score", 1:3, sep = "")),
         independent = list(gender = "sexRecoded", INCOME = c("income1", "income2")),
         complete.permutation = "no", glm.family = gaussian(link="identity") )
dG(mod1, analyses = 1)


###################################################
### code chunk number 21: regressionReplicationInteractiondef
###################################################
mod1  <- jk2.glm(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", JKZone = "JKZone",
         JKrep = "JKrep", groups = list(country = "country"),
         dependent = list(reading = paste("reading_score", 1:3, sep = "")),
         independent = list(gender = "sexRecoded", INCOME = c("income1", "income2")),
         reg.statement = "gender * INCOME",
         complete.permutation = "no", glm.family = gaussian(link="identity") )


###################################################
### code chunk number 22: regressionReplicationInteractionOutputdef
###################################################
dG(mod1, analyses = 1)


###################################################
### code chunk number 23: nestEx1def
###################################################
reading_writing[,"income_ind1"] <- factor(ifelse(reading_writing[,"income1"]>2000,"high","low"))
reading_writing[,"income_ind2"] <- factor(ifelse(reading_writing[,"income2"]>2000,"high","low"))


###################################################
### code chunk number 24: nestEx2def
###################################################
means  <- jk2.mean(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD", 
          JKZone = "JKZone", JKrep = "JKrep",
          groups = list(country = "country", INCOME = c("income_ind1","income_ind2")),
          dependent = list(ability = list(nest1 = paste("reading_score",1:3,sep=""),
                                          nest2 = paste("writing_score",1:3,sep="") )),
          complete.permutation = "no" )


###################################################
### code chunk number 25: nestEx2Resultsdef
###################################################
dM(means, omitTerms = c("var", "Ncases", "NcasesValid", "meanGroupDiff"))


###################################################
### code chunk number 26: nestEx3def
###################################################
mod1  <- jk2.glm(dat = reading_writing, ID = "idstud", wgt = "wgtSTUD",
          JKZone = "JKZone", JKrep = "JKrep",
          groups = list(country = "country", INCOME.group = c("income_ind1","income_ind2")),
          dependent = list(ability = list(nest1 = paste("reading_score",1:3,sep=""),
                                          nest2 = paste("writing_score",1:3,sep="") )),
          independent = list ( gender = "sex", INCOME = c("income1", "income2")),
          reg.statement = c("gender * INCOME"), glm.family = gaussian(link = "identity"),
          complete.permutation = "no" )
dG(mod1, analyses = 1)


