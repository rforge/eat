### R code from vignette source 'eatDesign.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
library(eatDesign)


###################################################
### code chunk number 2: table7def
###################################################
table7 <- data.frame ( "Booklet"  = c(1,1,2,2,3,3) ,
                       "Position" = c(1,2,1,2,1,2) ,
                       "Cluster"  = c(1,2,2,3,3,1) )

table7


###################################################
### code chunk number 3: design7def
###################################################
design7 <- defineDesign ( def = table7 )


###################################################
### code chunk number 4: design7show
###################################################
design7


###################################################
### code chunk number 5: linkListNames
###################################################
names(design7@linkList)


###################################################
### code chunk number 6: linkListPlot
###################################################
plot(design7@linkList[["Cluster|Booklet"]])


###################################################
### code chunk number 7: itemsdef
###################################################
itemsdef <- data.frame ( 
              "Item"    = paste("item",formatC(1:21,format="fg",width=2,flag="0"),sep=""),
              "Cluster" = c ( rep(1,7), rep(2,8), rep(3,6) ) )
itemsdef


###################################################
### code chunk number 8: itemsdefineDesign
###################################################
items <- defineDesign ( def = itemsdef )
items


###################################################
### code chunk number 9: itemPlot
###################################################
plot(items@linkList[["Item|Cluster"]])


###################################################
### code chunk number 10: design2
###################################################
design2 <- design7 + items
design2


###################################################
### code chunk number 11: itemPlot2
###################################################
plot(design2@linkList[["Item|Booklet"]])


