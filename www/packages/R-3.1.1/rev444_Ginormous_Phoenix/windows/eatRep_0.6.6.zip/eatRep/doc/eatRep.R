### R code from vignette source 'eatRep.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
library(eatRep)


###################################################
### code chunk number 2: reading_writingdef
###################################################
str(reading)


###################################################
### code chunk number 3: readingMeansByCountrydef
###################################################
readN1<- subset(reading, nest == 1 ) 
means <- jk2.mean(datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", groups = "country", 
         dependent = "score")


###################################################
### code chunk number 4: readingMeansByCountryResultsdef
###################################################
means[c(1:4,19:20),]


###################################################
### code chunk number 5: readingMeansByCountryResultsdefSummary
###################################################
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 6: readingMeansByCountry2def
###################################################
means <- jk2.mean(datL = readN1, ID = "idstud", wgt = "wgtSTUD", 
         imp = "imputation", groups = "country", dependent = "score")
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 7: readingMeansByCountry3def
###################################################
means <- jk2.mean(datL = readN1, ID = "idstud", 
         imp = "imputation", groups = "country", dependent = "score")
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 8: readingMeansByCountry4def
###################################################
means <- jk2.mean(datL = subset(readN1,imputation==1),  ID = "idstud", 
         imp = "imputation", groups = "country", dependent = "score")
dM(means, omitTerms = c("var", "Ncases","NcasesValid", "meanGroupDiff") )


###################################################
### code chunk number 9: readingMeansByCountry4def
###################################################
means <- jk2.mean(datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", groups = c("sex","country"), 
         group.splits = c(0,2), group.differences.by = "sex", dependent = "score")


###################################################
### code chunk number 10: readingMeansByCountry5def
###################################################
dM(means, omitTerms = c("var","Ncases", "NcasesValid"))


###################################################
### code chunk number 11: hiseiFreqsByCountryGenderdef
###################################################
freqs <- jk2.table( datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", groups = c("country", "sex"), 
	       dependent = "passed")
dT(freqs)


###################################################
### code chunk number 12: redefineValues2def
###################################################
readN1[,"passedNA"] <- readN1[,"passed"]
readN1[ sample(nrow(readN1), 100, FALSE) ,"passedNA"]   <- NA
freqs2<- jk2.table( datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", groups = c("country", "sex"), 
	       dependent = "passedNA", separate.missing.indicator = TRUE)
dT(freqs2)


###################################################
### code chunk number 13: regression1def
###################################################
mod1  <- jk2.glm(datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", groups = "country",
         formula = score~sex*income, family=gaussian(link="identity") )


###################################################
### code chunk number 14: regression1defResults1
###################################################
dG(mod1, analyses = 1:2)


###################################################
### code chunk number 15: regression2def
###################################################
mod1  <- jk2.glm(datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", 
         formula = passed~country*sex, family=binomial(link="logit") )
dG(mod1)


###################################################
### code chunk number 16: transformdef
###################################################
exp(mod1[c(1,3,5,7,9),"value"])


###################################################
### code chunk number 17: recodeSexdef
###################################################
readN1[,"sexRecoded"] <- car::recode(readN1[,"sex"], "'male' = '_male'")


###################################################
### code chunk number 18: regressionReplicationdef
###################################################
mod1  <- jk2.glm(datL = readN1, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", imp = "imputation", 
         formula = passed~country*sexRecoded, family=binomial(link="logit") )
dG(mod1)


###################################################
### code chunk number 19: nestEx2def
###################################################
means <- jk2.mean(datL = reading, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", nest="nest", imp = "imputation", 
         groups = "country", dependent = "score")
dM(means, omitTerms = c("var", "Ncases", "NcasesValid", "meanGroupDiff"))


###################################################
### code chunk number 20: nestEx3def
###################################################
mod1  <- jk2.glm(datL = reading, ID = "idstud", wgt = "wgtSTUD", type = "JK2", 
         PSU = "JKZone", repInd = "JKrep", nest="nest", imp = "imputation", 
         groups = "country", formula = score~sex+income, family=gaussian(link="identity") )
dG(mod1)


