####################################################################################################################
#
# function:
# removeNArows ( data , cols = NULL , tolerance = 0 , cumulate = TRUE , method = c("remove", "identify") , warn = FALSE )
#
# description:
# removes or identifies rows with NA
#
# arguments:
# data: matrix or dataframe
# cols: columns (numeric vector or column names) or list of column subsets that are tested for NA, default: all columns
# tolerance: number or list of numbers (corresponding to column subsets) of allowed non-NA 
# cumulate: if TRUE rows that match tolerance criterion are cumulated, if FALSE rows that match NA pattern exactly are removed or identified
# method: "remove" removes rows from data , "identify" identifies rows to be removed
# warn: if TRUE a warning is issued when rows are removed (method="remove" only)
#
# value:
# method="remove" returns matrix or dataframe with rows removed
# method="identify" returns list of rows that were identified to be removed
#
# Version: 	0.1.0
# Depends: 	codeKlandestin
# Imports: 	
# Published: 	2011-08-08
# Author: 	Martin Hecht
# Maintainer: 	Martin Hecht
#
# Change-Log
# 08.08.2011 MH: auf stable gesetzt wegen besserer sourcebarkeit
#				 Dependencies rausgenommen, muss jetzt �ber source.it.all gesourct werden
# 24.01.2011 MH		option "cumulate" added
# 15.01.2011 MH		argument method added
# 14.01.2011 MH		arguments tolerance and column subsets added
# 06.01.2011 MH
#
####################################################################################################################

removeNArows <- function( data , cols = NULL , tolerance = 0 , cumulate = TRUE , method = c("remove", "identify") , warn = FALSE ) {

		# Dependencies
		#source("c:/R/codeKlandestin_0.0.1.R")
		#source("p:/ZKD/stable/latest/codeKlandestin.R")
		#source("p:/ZKD/development/codeKlandestin_0.0.2.R")
		
		return ( removeNA ( data , cols , tolerance , cumulate , method , warn , mode="rows") )
		
}


####################################################################################################################
# E x a m p l e s
####################################################################################################################

### example matrix
#( mat <- matrix( c( 1,1,1,1,1, 1,1,1,1,NA, 1,1,1,NA,NA, 1,1,NA,NA,NA, 1,NA,NA,NA,NA, NA,NA,NA,NA,NA ) , ncol=5 , byrow=TRUE ) )

### remove row with entirely NA (row 6)
#removeNArows( mat )

### warning message if rows are removed
#removeNArows( mat , warn = TRUE )

### remove row with NA on column 3, 4, 5 (rows 4, 5, 6)
#removeNArows( mat , c(3,4,5) ) 
#removeNArows( mat , c(-1,-2) ) 

### tolerance=1 , 1 non-NA is permitted (rows 5 and 6)
#removeNArows( mat , tolerance=1 ) 

### tolerance=5 , 5 non-NA are permitted (all rows are removed)
#removeNArows( mat , tolerance=5 ) 

### do not cumulate / exact tolerance (row 1 is removed)
#removeNArows( mat , tolerance=5 , cumulate=FALSE ) 
#removeNArows( mat , tolerance=5 , cumulate=FALSE , method="identify") 

### two subsets of columns
#removeNArows( mat , cols = list( c(1, 2), c(4, 5) ) )

### two subsets of columns with different tolerance
#removeNArows( mat , cols = list( c(1), c(2, 3, 4, 5) ) , tolerance = list( 0 , 1 ) )

### identify rows, no deletion
#removeNArows( mat , cols = list( c(1), c(2, 3, 4, 5) ) , tolerance = list( 0 , 1 ) , method = "identify" )



####################################################################################################################
# T e s t s
####################################################################################################################

### test matrix
#( mat <- matrix( c( 1,1,1,1,1, 1,1,1,1,NA, 1,1,1,NA,NA, 1,1,NA,NA,NA, 1,NA,NA,NA,NA, NA,NA,NA,NA,NA ) , ncol=5 , byrow=TRUE ) )
#( mat.char1 <- matrix(as.character(mat), ncol=5 ) )
#( dafr <- as.data.frame(mat) )

### no data argument
#removeNArows()

### defaults
#removeNArows(mat)
#removeNArows(mat.char1)
#removeNArows(dafr)

### not supported method
#removeNArows( mat , method = "bla" )

### colnames
#removeNArows( dafr , cols=c(1,2,3,4,5) )
#removeNArows( dafr , cols=c("V1","V2","V3","V4","V5") )
#removeNArows( dafr , cols=list( c("V1","V2") , c(3,4,5)  ) )

### wrong cols argument
#removeNArows( mat , cols=c("jklfs","kjkljl") )
#removeNArows( mat , cols=list("jklfs","kjkljl") )

### wrong tolerance argument
#removeNArows( mat , tolerance="1" )
#removeNArows( mat , tolerance="dasfadsf" )

### return vector / list
#removeNArows( mat , tolerance=5 , cumulate=TRUE , method="identify") 
#removeNArows( mat , tolerance=5 , cumulate=FALSE , method="identify") 
#removeNArows( mat , cols = list( c(1), c(2, 3, 4, 5) ) , tolerance = list( 0 , 1 ) , cumulate = FALSE , method = "identify" )
#removeNArows( mat , cols = list( c(1), c(2, 3, 4, 5) ) , tolerance = list( 0 , 1 ) , cumulate = TRUE , method = "identify" )
#removeNArows( mat , tolerance=1 , cumulate = FALSE , method = "identify") 








