####################################################################################################################
#
# writeResultsExcel
# schreibt Ergebnisse der Conquest Analysen die durch die Funktion readConquestOutput
#  eingelesen wurden in eine Excel Datei (.xlsx).
#
# Version: 	0.4.0
# Imports:
# Published:
# Author:  Malte Jansen, Christiane Penk, Sebastian Wurster
# Maintainer: Klaus & Nikolaus
#
#
# Change log:
#   26.08.2011 MH: auf stable gesetzt wegen besserer Sourcebarkeit
#   17.08.2011 MH: auf stable gesetzt wegen besserer Sourcebarkeit
#	0.2.0 : additional_itemprops eingef�gt
#	0.0.4-0.0.5: Selektion und Subskala raus; Analysename und Gruppenname rein (erstmal als Platzhalter)
#   0.0.6 : ZKD-Ergebnisstruktur 1:1 �bernommen; b.cent raus
#	0.1.0 : Funktionierende Version f�r eine Analyse
#	0.2.0 : Funktionierende Version f�r mehrere Analysen
#   0.3.2 : Personenkennwerte rausschreiben in Extra-Tabelle eingef�gt
#   0.3.3 : Personenkennwerte jetzt mit PVs!! (ACHTUNG: Funktioniert nur f�r f�nf PVs, muss ncoh angepasst werden)
#
####################################################################################################################
# Basis: ZKD-Ergebnisliste 
#	- Konzept: p:\ZKD\01_Organisation\Konzepte\ErgebnisStruktur_Konzept_05.xlsx
#	- Output von ReadConquestOutput 
#
#Ziel: 
# Es werden 2 Excel Dateien rausgeschrieben: 
#	1. Ergebnisse f�r Items mit zwei Tabellenbl�ttern (Itemkennwerte, Kategorietrennsch�rfe)
#	2. Ergebnisse f�r Personen
#
#
# Input:
# results = ZKD-Ergebnisliste (Struktur siehe p:\ZKD\01_Organisation\Konzepte\ErgebnisStruktur_Konzept_05.xlsx)
# path = Folder wo die Excel-Tabelle hingespeichert werden soll
#
#Aktueller Stand: Itemkennwerte rausschreiben klappt f�r eine Analyse
#
# TODO
# Schleife �ber alle Analysen
# Schleife �ber alle Personengruppen
# nochmal write.xlsx 2 testen
# Kategorietrennsch�rfen rausschreiben
###write.xlsx(kategorie.matrix, paste(Pfad, name.analyse, ".xlsx", sep=""), sheetName = "Kategorietrennschaerfe", row.names = FALSE, append = TRUE)
# Personenkennwerte rausschreiben
# NAs als Leerstring statt "NV" in Ergebnistabelle
## 
#####################################################################################################################


write.results.xlsx <- function ( results, path, additional_itemprops=NULL ) {

	analysen <- names (results)

	sammel.itemkennwerte <- NULL
	sammel.personenkennwerte <- NULL
	sammel.cat <- NULL
	sammel.dif <- NULL
	for (analyse in analysen) {
			
			#results [[analyse]]
			itemalle <- names (results [[analyse]][[1]][[1]])

			results.matrix <- as.numeric()

					for (item in itemalle) {
						
						Analysename <- analyse 
						Gruppenname <- names (results [[analyse]][[1]])#Platzhalter, wird eingebaut
							if(is.null(Gruppenname) == TRUE) Gruppenname <- NA
						n.valid <- (results [[analyse]] [[1]] [[1]] [[item]]$n.valid)
							if(is.null(n.valid) == TRUE) n.valid <- NA
						p <- (results [[analyse]] [[1]] [[1]] [[item]]$p)
							if(is.null(p) == TRUE) p <- NA
						a <-	(results [[analyse]] [[1]] [[1]] [[item]]$a)
							if(is.null(a) == TRUE) a <- NA 
						b <- (results [[analyse]] [[1]] [[1]] [[item]]$b)
							if(is.null(b) == TRUE) b <- NA # muss hier so gemacht werden, da in readConquest mis <- NULL gesetzt ist, wenn mis <- NA kann das hier gel�scht werden
						c <- 	(results [[analyse]] [[1]] [[1]] [[item]]$c)
							if(is.null(c) == TRUE) c <- NA 
						d <- 	(results [[analyse]] [[1]] [[1]] [[item]]$d)
							if(is.null(d) == TRUE) d <- NA 
						b.se	<-(results [[analyse]] [[1]] [[1]] [[item]]$b.se)
							if(is.null(b.se) == TRUE) b.se <- NA
						infit	<- (results [[analyse]] [[1]] [[1]] [[item]]$infit)
							if(is.null(infit) == TRUE) infit <- NA
						infit.ci.lb <-(results [[analyse]] [[1]] [[1]] [[item]]$infit.ci.lb)
							if(is.null(infit.ci.lb) == TRUE) infit.ci.lb <- NA
						infit.ci.ub <-(results [[analyse]] [[1]] [[1]] [[item]]$infit.ci.ub)
							if(is.null(infit.ci.ub) == TRUE) infit.ci.ub <- NA
						infit.t <- (results [[analyse]] [[1]] [[1]] [[item]]$infit.t)
							if(is.null(infit.t) == TRUE) infit.t <- NA
						outfit	<- (results [[analyse]] [[1]] [[1]] [[item]]$outfit)
							if(is.null(outfit) == TRUE) outfit <- NA
						outfit.ci.lb  <- (results [[analyse]] [[1]] [[1]] [[item]]$outfit.ci.lb)
							if(is.null(outfit.ci.lb) == TRUE) outfit.ci.lb <- NA
						outfit.ci.ub <- (results [[analyse]] [[1]] [[1]] [[item]]$outfit.ci.ub)
							if(is.null(outfit.ci.ub) == TRUE) outfit.ci.ub <- NA
						outfit.t <- (results [[analyse]] [[1]] [[1]] [[item]]$outfit.t)
							if(is.null(outfit.t) == TRUE) outfit.t <- NA
						pbc	<- (results [[analyse]] [[1]] [[1]] [[item]]$pbc)
							if(is.null(pbc) == TRUE) pbc <- NA
						b.eval	<- (results [[analyse]] [[1]] [[1]] [[item]]$b.eval)
							if(is.null(b.eval) == TRUE) b.eval <- NA
						infit.eval	<- (results [[analyse]] [[1]] [[1]] [[item]]$infit.eval)
							if(is.null(infit.eval) == TRUE) infit.eval <- NA
						pbc.eval	<- (results [[analyse]] [[1]] [[1]] [[item]]$pbc.eval)
							if(is.null(pbc.eval) == TRUE) pbc.eval <- NA
						eval.num	<- (results [[analyse]] [[1]] [[1]] [[item]]$eval.num)
							if(is.null(eval.num) == TRUE) eval.num <- NA
						eval	<- (results [[analyse]] [[1]] [[1]] [[item]]$eval)
							if(is.null(eval) == TRUE) eval <- NA	
						results.vector <- c (Analysename, item, Gruppenname, n.valid, p, a, b, c, d,
										b.se,  infit, infit.ci.lb, infit.ci.ub, infit.t, outfit, outfit.ci.lb, outfit.ci.ub, outfit.t, pbc,
										b.eval, infit.eval, pbc.eval, eval.num, eval)
						
						
						results.matrix <- rbind ( results.matrix, results.vector  )
						
						##todo: Kategorietrennsch�rfen auf Extra-Tabellenblatt
						#catalle <- names (results [[1]][[1]][[1]]$cat) 
						##todo: DIF auf Extra-Tabellenblatt
						# sammeln, dif
						
						
						
					}

				colnames(results.matrix) <- c ("Analysename","item", "Gruppenname","n.valid", "p", "a", "b", "c", "d",
								"b.se",  "infit", "infit.ci.lb", "infit.ci.ub", "infit.t", "outfit", "outfit.ci.lb", "outfit.ci.ub", "outfit.t", "pbc",
								"b.eval", "infit.eval", "pbc.eval", "eval.num", "eval")
				rownames(results.matrix) <- NULL

				
				
				# sammeln
				if ( is.null ( sammel.itemkennwerte ) ) sammel.itemkennwerte <- results.matrix else sammel.itemkennwerte <- rbind ( sammel.itemkennwerte , results.matrix )
				
	}	

	if ( ! ( l <- length ( analysen ) ) == 1 ) out.name <- paste ( "Gesamt_" , l , "_Analysen" , sep="" ) else out.name <- analysen	

	sammel.itemkennwerte <- data.frame ( sammel.itemkennwerte , stringsAsFactors = FALSE )
	

				sammel.itemkennwerte$Analysename <- as.character(sammel.itemkennwerte$Analysename)
				sammel.itemkennwerte$item <- as.character(sammel.itemkennwerte$item)
				sammel.itemkennwerte$Gruppenname <- as.character(sammel.itemkennwerte$Gruppenname)
				sammel.itemkennwerte$n.valid <- as.numeric(sammel.itemkennwerte$n.valid)
				sammel.itemkennwerte$p <- as.numeric(sammel.itemkennwerte$p)
				sammel.itemkennwerte$a <- as.numeric(sammel.itemkennwerte$a)
				sammel.itemkennwerte$b <- as.numeric(sammel.itemkennwerte$b)
				sammel.itemkennwerte$c <- as.numeric(sammel.itemkennwerte$c)
				sammel.itemkennwerte$d <- as.numeric(sammel.itemkennwerte$d)
				sammel.itemkennwerte$b.se <- as.numeric(sammel.itemkennwerte$b.se)
				sammel.itemkennwerte$infit <- as.numeric(sammel.itemkennwerte$infit)
				sammel.itemkennwerte$infit.ci.lb <- as.numeric(sammel.itemkennwerte$infit.ci.lb)
				sammel.itemkennwerte$infit.ci.ub <- as.numeric(sammel.itemkennwerte$infit.ci.ub)
				sammel.itemkennwerte$infit.t <- as.numeric(sammel.itemkennwerte$infit.t)
				sammel.itemkennwerte$outfit <- as.numeric(sammel.itemkennwerte$outfit)
				sammel.itemkennwerte$outfit.ci.lb <- as.numeric(sammel.itemkennwerte$outfit.ci.lb)
				sammel.itemkennwerte$outfit.ci.ub <- as.numeric(sammel.itemkennwerte$outfit.ci.ub)
				sammel.itemkennwerte$outfit.t <- as.numeric(sammel.itemkennwerte$outfit.t)
				sammel.itemkennwerte$pbc <- as.numeric(sammel.itemkennwerte$pbc)
				sammel.itemkennwerte$b.eval <- as.character(sammel.itemkennwerte$b.eval)
				sammel.itemkennwerte$infit.eval <- as.character(sammel.itemkennwerte$infit.eval)
				sammel.itemkennwerte$pbc.eval <- as.character(sammel.itemkennwerte$pbc.eval)
				sammel.itemkennwerte$eval.num <- as.numeric(sammel.itemkennwerte$eval.num)
				sammel.itemkennwerte$eval <- as.character(sammel.itemkennwerte$eval)
	
	## todo: hier noch Itemprops ranmergen
	### automate models �bergibt dataframe mit namen "additional_itemprops"
	### diese Itemeigenschaften sollen auch in Tabelle
	### plausicheck ob item �berschrift irgendeiner spalte ist ; which colname is die itemid
	### if nume
	### wenn nicht, wird die erste Spalte genommen und ausgabe mit hinweis (cat (paste("asdsad"))
	### 

	if ( ! is.null ( additional_itemprops ) ) {
			if ( ! any ( colnames ( additional_itemprops ) == "item" ) ) {
					cat ( paste ( "\nadditional item prop konnte nicht an Ergebnisse rangemergt werden, da Spalte 'item' fehlt" ) )
			} else {
					sammel.itemkennwerte <- merge ( sammel.itemkennwerte , additional_itemprops , by = "item" ) 
			}
	}
	
	# Excel
	write.xlsx ( sammel.itemkennwerte , file.path ( path , paste( out.name , ".xlsx", sep="") ), sheetName = "Itemkennwerte", row.names = TRUE )
	
	# Rdata Frame
	save ( sammel.itemkennwerte , file = file.path ( path , paste( out.name , ".Rdata", sep="" ) ) )
	
	
	
######### Personenkennwerte ###############
	
		for (analyse in analysen) {
			
			#results [[analyse]]
			personenalle <- names (results [[analyse]][[2]][[1]])   # Personenids

			results.matrix <- as.numeric()

					for (person in personenalle) {
						
						
						Analysename <- analyse 
						Dimension <- names (results [[analyse]][[2]])
							if(is.null(Dimension) == TRUE) Dimension <- NA
						n.solved <- (results [[analyse]] [[2]] [[1]] [[person]]$n.solved)
							if(is.null(n.solved) == TRUE) n.solved <- NA
						n.total <- (results [[analyse]] [[2]] [[1]] [[person]]$n.total)
							if(is.null(n.total) == TRUE) n.total <- NA
						wle <- (results [[analyse]] [[2]] [[1]] [[person]]$wle)
							if(is.null(wle) == TRUE) wle <- NA							
						wle.se <- (results [[analyse]] [[2]] [[1]] [[person]]$wle.se)
							if(is.null(wle.se) == TRUE) wle.se <- NA								
						eap <- (results [[analyse]] [[2]] [[1]] [[person]]$eap)
							if(is.null(eap) == TRUE) eap <- NA							
						eap.se <- (results [[analyse]] [[2]] [[1]] [[person]]$eap.se)
							if(is.null(eap.se) == TRUE) eap.se <- NA							
						
					
						
						plauvals <- names (results [[analyse]][[2]][[1]] [[person]] $pv ) 

						pv.vector <- as.numeric ()
						
							for (plauval in plauvals) {
								pv_temp <- (results [[analyse]] [[2]] [[1]] [[person]] $pv [[plauval]])
								if(is.null(pv_temp) == TRUE) pv_temp <- NA									
							
								pv.vector <- c ( pv.vector, pv_temp  )   
						}

				results.vector <- c (person,Analysename, Dimension, n.solved,n.total,wle,wle.se,eap,eap.se,pv.vector )
				
				
				results.matrix <- rbind ( results.matrix, results.vector  )					

				}	
				
				colnames(results.matrix) <- c ("Person","Analysename","Dimension","n.solved","n.total","wle","wle.se","eap","eap.se","pv1","pv2","pv3","pv4","pv5")
				rownames(results.matrix) <- NULL

				
				
				# sammeln
				if ( is.null ( sammel.personenkennwerte ) ) sammel.personenkennwerte <- results.matrix else sammel.personenkennwerte <- rbind ( sammel.personenkennwerte , results.matrix )
				
		
	
	}
	if ( ! ( l <- length ( analysen ) ) == 1 ) out.name <- paste ( "Gesamt_" , l , "_Analysen" , sep="" ) else out.name <- analysen	

	sammel.personenkennwerte <- data.frame ( sammel.personenkennwerte , stringsAsFactors = FALSE )
	

				sammel.personenkennwerte$Analysename <- as.character(sammel.personenkennwerte$Analysename)
				sammel.personenkennwerte$Dimension <- as.character(sammel.personenkennwerte$Dimension)
				sammel.personenkennwerte$n.solved <- as.numeric(sammel.personenkennwerte$n.solved)
				sammel.personenkennwerte$n.total <- as.numeric(sammel.personenkennwerte$n.total)
				sammel.personenkennwerte$wle <- as.numeric(sammel.personenkennwerte$wle)
				sammel.personenkennwerte$wle.se <- as.numeric(sammel.personenkennwerte$wle.se)	
				sammel.personenkennwerte$eap <- as.numeric(sammel.personenkennwerte$eap)
				sammel.personenkennwerte$eap.se <- as.numeric(sammel.personenkennwerte$eap.se)		
				sammel.personenkennwerte$pv1 <- as.numeric(sammel.personenkennwerte$pv1)	
				sammel.personenkennwerte$pv2 <- as.numeric(sammel.personenkennwerte$pv2)
				sammel.personenkennwerte$pv3 <- as.numeric(sammel.personenkennwerte$pv3)
				sammel.personenkennwerte$pv4 <- as.numeric(sammel.personenkennwerte$pv4)
				sammel.personenkennwerte$pv5 <- as.numeric(sammel.personenkennwerte$pv5)				
	# Excel
	write.xlsx ( sammel.personenkennwerte , file.path ( path , paste( out.name ,"_person", ".xlsx", sep="") ), sheetName = "Personenkennwerte", row.names = TRUE)
	
	# Rdata Frame
	save ( sammel.personenkennwerte , file = file.path ( path , paste( out.name ,"_person", ".Rdata", sep="" ) ) )
		
	
	return ( TRUE )	
		

}

##todo: Personenwerte als Extra-tabelle

# TESTEN
###Test mit Beispieldaten (eine Analyse)
# load ('p:\\ZKD\\02_Beispieldaten\\BspResults02.Rdata')
# load ('p:\\ZKD\\temp\\13_ReadConquestResults\\results.Rdata')
# library ( xlsx )
# results <- BspResults02
# path <- "P:/ZKD/temp/13_ReadConquestResults/"

# library(debug)
# mtrace(write.results.xlsx)
# write.results.xlsx (results, path)
